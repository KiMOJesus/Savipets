import Foundation
import OSLog

// Some other Swift code
struct Example {
    let id: Int
}
